import { Component } from '@angular/core';

interface Employee {
  id: number;
  name: string;
  punchInTime: Date | null;
  punchOutTime: Date | null;
  totalTime: string | null;
  photo: string | null;
}
@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
  styleUrl: './manager-dashboard.component.css'
})
export class ManagerDashboardComponent {
  employees: Employee[] = [];
  newEmployee: Employee = {
    id: 0,
    name: '',
    punchInTime: null,
    punchOutTime: null,
    totalTime: null,
    photo: null
  };

  constructor() { }

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees() {
    const storedEmployees = localStorage.getItem('employees');
    if (storedEmployees) {
      this.employees = JSON.parse(storedEmployees);
    }
  }

  addEmployee() {
    if (this.newEmployee.id && this.newEmployee.name) {
      this.employees.push({ ...this.newEmployee });
      this.saveToLocalStorage();
      this.newEmployee = { id: 0, name: '', punchInTime: null, punchOutTime: null, totalTime: null, photo: null };
    } else {
      alert('Please enter valid employee details.');
    }
  }

  deleteEmployee(employeeId: number) {
    this.employees = this.employees.filter(emp => emp.id !== employeeId);
    this.saveToLocalStorage();
  }

  updateEmployee(employee: Employee) {
    debugger
    const existingEmployeeIndex = this.employees.findIndex(emp => emp.id === employee.id);
    if (existingEmployeeIndex !== -1) {
      this.employees[existingEmployeeIndex] = { ...employee };
      this.saveToLocalStorage();
    }
  }

  saveToLocalStorage() {
    localStorage.setItem('employees', JSON.stringify(this.employees));
  }
}
