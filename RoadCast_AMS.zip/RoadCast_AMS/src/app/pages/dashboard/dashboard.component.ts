import { Component } from '@angular/core';


interface Employee {
  id: number;
  name: string;
  punchInTime: Date | null;
  punchOutTime: Date | null;
  totalTime: string | null;
}


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  employees: Employee[] = [];

  ngOnInit(): void {
    this.loadEmployees();
  }

  // Load all employee data from localStorage
  loadEmployees() {
    const storedEmployees = localStorage.getItem('employees');
    if (storedEmployees) {
      this.employees = JSON.parse(storedEmployees);
    }
  }

}
