import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth-service.service';

@Component({
  selector: 'app-manager-login',
  templateUrl: './manager-login.component.html',
  styleUrl: './manager-login.component.css'
})
export class ManagerLoginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router, private authService: AuthService) { }

  // Manager Login Functionality
  login() {
    if (this.username === 'manager' && this.password === 'manager123') {
      this.authService.login('dummy-token');
      localStorage.setItem('loggedInManager', this.username);  // Store manager login
      this.router.navigate(['/manager-dashboard']);  // Navigate to dashboard
    } else {
      alert('Invalid manager credentials!');
    }
  }
}
