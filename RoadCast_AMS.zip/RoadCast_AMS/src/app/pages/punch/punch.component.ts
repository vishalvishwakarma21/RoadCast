import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { WebcamImage, WebcamInitError } from 'ngx-webcam';

interface Employee {
  id: number;
  name: string;
  punchInTime: Date | null;
  punchOutTime: Date | null;
  totalTime: string | null;
  photo: string | null;
}
@Component({
  selector: 'app-punch',
  templateUrl: './punch.component.html',
  styleUrl: './punch.component.css'
})
export class PunchComponent {
  employee: Employee = {
    id: 0,
    name: '',
    punchInTime: null,
    punchOutTime: null,
    totalTime: null,
    photo: null
  };



  employees: Employee[] = [];
  public showWebcam: boolean = false;
  public webcamImage: WebcamImage | undefined;
  private trigger: Subject<void> = new Subject<void>();
  isPunchedIn: boolean = false;

  public triggerSnapshot(): void {
    this.trigger.next();
  }
  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    console.log('Captured image:', this.webcamImage);
    this.employee.photo = webcamImage.imageAsDataUrl;
    this.showWebcam = false;
  }

  get triggerObservable() {
    return this.trigger.asObservable();
  }
  // Toggle the webcam visibility
  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }


  punchIn() {
    debugger
    if (this.employee.name && this.employee.id) {
      this.employee.punchInTime = new Date();
      this.isPunchedIn = true;
      alert("Punched In Successfully!");
      this.saveToLocalStorage();
    } else {
      alert('Please enter employee details!');
    }
  }

  punchOut() {
    if (this.employee.punchInTime) {
      this.employee.punchOutTime = new Date();
      const duration = this.employee.punchOutTime.getTime() - this.employee.punchInTime.getTime();
      this.employee.totalTime = this.formatDuration(duration);
      this.isPunchedIn = false;
      alert("Punched Out Successfully!");
      this.saveToLocalStorage();
    }
  }

  formatDuration(duration: number): string {
    const seconds = Math.floor((duration / 1000) % 60);
    const minutes = Math.floor((duration / (1000 * 60)) % 60);
    const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
    return `${hours} hrs ${minutes} mins ${seconds} secs`;
  }

  saveToLocalStorage() {
    let employees = JSON.parse(localStorage.getItem('employees') || '[]');
    const existingEmployeeIndex = employees.findIndex((emp: Employee) => emp.id === this.employee.id);
    if (existingEmployeeIndex !== -1) {
      employees[existingEmployeeIndex] = this.employee;
    } else {
      employees.push(this.employee);
    }
    localStorage.setItem('employees', JSON.stringify(employees));
  }

}
