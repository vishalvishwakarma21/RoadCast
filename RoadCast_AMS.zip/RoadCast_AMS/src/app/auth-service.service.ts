import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() { }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('managerToken');
  }

  login(token: string): void {
    localStorage.setItem('managerToken', token);
  }

  logout(): void {
    localStorage.removeItem('managerToken');
  }
}
